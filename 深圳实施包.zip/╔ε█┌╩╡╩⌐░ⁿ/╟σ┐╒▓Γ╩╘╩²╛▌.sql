delete from booking
delete from bookingadd
delete from delayservice
delete from reservice
delete from sacars
delete from serviceaddhours
delete from servicepause
delete from servicepauseold
delete from syslog
delete from syspower
delete from updatemsg 
delete from usermsg
delete from versionuser
update workhours set jdhours=0,usejdhours=0,cshours=0,sumcars=0,sumcarsbook=0,sumcarsnobook=0
